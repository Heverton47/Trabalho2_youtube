# PogVideo (My Application)

## Como abrir e executar
1. Android Studio com suporte ao AGP 9.3 (use a versão estável mais recente) e SDK Platform 37 instalado (SDK Manager).
2. File > Open > pasta deste projeto. Aguarde o Gradle Sync (baixa o Gradle 9.5.0 pelo wrapper).
3. Gradle JDK: 17 ou superior (o JDK embutido do Android Studio serve). Isso é o JDK que EXECUTA o build; o código continua com compatibilidade Java 11.
4. Run ▶ em um emulador/dispositivo com Android 7.0+ (API 24+).

Ferramentas: AGP 9.3.0, Gradle 9.5.0, Kotlin 2.4.21 (plugins Compose e Serialization na mesma versão), Compose BOM 2026.09.00, Navigation 2.10.2, compileSdk/targetSdk 37, minSdk 24.

## Roteiro de demonstração
1. Abre em Início. Toque no vídeo 1 → abre "UM DIA COMIGO"; Voltar → Início.
2. Aba Inscrições: aparece a mensagem de vazio. Em "Canais disponíveis" toque no Canal 1 → mostra Canal 1 com vídeos 1 e 3. Toque em "Inscrever-se".
3. Voltar → Inscrições agora lista o Canal 1 (inscrito) e o Canal 2 continua em "disponíveis".
4. Toque no Canal 2 → mostra Canal 2 com só o vídeo 2 (RDR2). Toque no vídeo → abre o vídeo 2.
5. Na tela do vídeo, "Inscrever-se" e depois volte em Inscrições: o Canal 2 passou a inscrito (estado compartilhado). "Inscrito" na lista cancela a inscrição.
6. Aba Você: perfil, botões Inscrições/Configurações, Histórico (abre vídeo) e Playlists.
   - "Assistir mais tarde" → vídeos 1 e 3; "Gameplays" → vídeo 2; "Playlist vazia" → mensagem de vazio. Toque num vídeo → abre aquele vídeo; Voltar → Playlist → Voltar → Você.
7. Toque várias vezes na mesma aba: não empilha cópias.
