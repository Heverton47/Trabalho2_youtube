// Arquivo de build da raiz: só declara os plugins (sem aplicar) para o módulo :app.
// Com o Kotlin embutido do AGP 9, não é preciso o plugin org.jetbrains.kotlin.android.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.kotlin.serialization) apply false
}
