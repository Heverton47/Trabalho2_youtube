# PogVideo — Trabalho 2 (MAF: Mínimo Aplicativo Funcional)

Aplicativo Android em **Kotlin + Jetpack Compose** que simula o YouTube. Continuação do Trabalho 1 (telas estáticas): agora o app tem navegação real, dados em memória e listas dinâmicas.

**Integrantes:** Admar · Heverton · Caio

---

## O que é

Um clone simplificado do YouTube com tema escuro. O usuário vê um feed de vídeos, abre um vídeo, visita o canal de quem o publicou, se inscreve em canais, acessa suas playlists e as configurações. A navegação é feita por uma barra inferior (`NavigationBar`), uma barra superior (`TopAppBar`) e pelos itens clicáveis das telas.

### Telas

| Tela | Rota | Responsável | Função |
|---|---|---|---|
| Início | `inicio` | Admar | Feed de vídeos (`LazyColumn`). Clicar abre o vídeo certo. |
| Vídeo Aberto | `video/{videoId}` | Admar | Detalhes do vídeo: título, canal, visualizações, curtidas, descrição expansível, comentários e botão de inscrição. |
| Ver Canal | `canal/{canalId}` | Heverton | Página de um canal: descrição, inscrição e lista dos vídeos dele. |
| Configurações | `configuracoes` | Heverton | Opções com `Checkbox`, seção "Sobre" expansível e atalhos para Inscrições e Playlist. |
| Inscrições | `inscricoes` | Caio | Canais inscritos e canais disponíveis (`LazyColumn`), com mensagem quando a lista está vazia. |
| Você | `voce` | Caio | Perfil, atalhos para Inscrições e Configurações, histórico e playlists. |
| Playlist | `playlist/{playlistId}` | Caio | Vídeos de uma playlist; clicar em um vídeo abre a tela dele. |

## Como rodar

1. Use um Android Studio com suporte ao **AGP 9.3** (versão estável mais recente) e instale o **SDK Platform 37** pelo SDK Manager.
2. `File > Open` na pasta do projeto e aguarde o **Gradle Sync** (o wrapper baixa o Gradle 9.5.0).
3. Gradle JDK 17 ou superior (o JDK embutido do Android Studio serve).
4. Clique em **Run** em um emulador ou celular com Android 7.0+ (API 24+).

Ferramentas: AGP 9.3.0, Gradle 9.5.0, Kotlin 2.4.21, Compose BOM 2026.09.00, Navigation Compose 2.10.2, `material-icons-extended`, compileSdk/targetSdk 37 e minSdk 24.

> Os dados vivem só na memória (`mutableStateListOf`). Ao fechar o app, o que foi alterado se perde. Isso é esperado nesta etapa.

## O que tem de novo (em relação ao Trabalho 1)

- **Navegação real:** um `NavHost` central em `AppNavigation.kt` e um `object Rotas` com as rotas como `const val`.
- **Barra inferior** (`BottomNavigation.kt`): `NavigationBar` com Início, Inscrições e Você, destacando a aba ativa. Tocar várias vezes na mesma aba não empilha telas repetidas (`popUpTo` + `launchSingleTop`).
- **Barra superior** (`TopNavigation.kt`): muda conforme a tela. Nas telas principais mostra o logo e ações (incluindo a engrenagem de Configurações). Nas secundárias mostra o botão de voltar com `popBackStack()`.
- **Três tipos de dado:** `Video`, `Canal` e `ListaReproducao` (playlist). Vídeos e canais ficam em listas reativas (`listaVideos`, `listaCanais`).
- **Item certo na tela certa:** cada lista envia só o **id** (do vídeo, do canal ou da playlist) pela rota, e a tela de destino busca o item.
- **Relação entre os dados, sem duplicação:** `Video` guarda um `canalId`, e `videosDoCanal(canalId)` filtra os vídeos de um canal. A playlist guarda só os `videoIds`, e `videosDaPlaylist()` os resolve na `listaVideos`.
- **Estado de inscrição compartilhado:** `alternarInscricao(canalId)` altera o `Canal` na `listaCanais`. Inscrever-se no Vídeo Aberto ou no Ver Canal atualiza a tela de Inscrições.
- **Listas vazias tratadas:** Inscrições e Playlist mostram uma mensagem e um atalho para explorar vídeos.

## Como foi o desenvolvimento

### Divisão de tarefas

- **Admar:** `Class_Video.kt`, `Inicio.kt`, `Video_Aberto.kt`
- **Heverton:** `AppNavigation.kt`, `Rotas.kt`, `BottomNavigation.kt`, `TopNavigation.kt`, `Ver_Canal.kt`, `Configuracoes.kt`
- **Caio:** `Voce.kt`, `Playlist.kt`, `Inscricoes.kt` (e as classes `Class_Playlist.kt` e `Class_Canal.kt`)

### Decisões de organização do código

- **Rotas centralizadas** em `Rotas.kt`. Rotas com argumento têm uma função que monta o caminho (`Rotas.videoAberto(id)`, `Rotas.verCanal(id)`, `Rotas.playlist(id)`), o que evita erro de digitação.
- **Uma lista única por tipo de item**, em `Class_Video.kt` e `Class_Canal.kt`, acessível por todas as telas.
- **Barras fora das telas:** o `Scaffold` fica em `AppNavigation.kt`, com `TopNavBar` e `BottomNavBar`. Cada tela cuida só do próprio conteúdo. A barra inferior aparece em Início, Inscrições, Você e Ver Canal.
- **Passagem por id**, e não pelo objeto inteiro, para a tela de destino sempre ler o dado atual da lista.

#### Decisões registradas pelo Admar

- **Manter o tema YouTube do Trabalho 1** e usar um print do YouTube real como modelo visual da tela Vídeo Aberto (player, título, canal com "Inscrever-se", curtir, descurtir, compartilhar e card de comentários).
- **Uma única lista de vídeos (`listaVideos`) em `Class_Video.kt`.** Assim `Inicio` e `Video_Aberto` leem os mesmos dados.
- **Passar só o `videoId` pela rota.** O `Inicio` envia o id e o `Video_Aberto` busca o vídeo com `find`. Se o id não existir, a tela mostra "Vídeo não encontrado" em vez de travar.
- **Fazer os botões do vídeo funcionarem de verdade.** Curtir, descurtir e expandir a descrição usam `remember` e mudam de cor ou de texto. Curtir e descurtir se excluem, como no YouTube.
- **Miniaturas em cor sólida** (`corMiniatura`), em vez de imagens, para o projeto ficar simples e sem arquivos externos.
- **Usar títulos e canais reais como exemplo.** Os vídeos 2 e 3 vieram de um print do YouTube (DMenor11 e TNT Sports Brasil). Curtidas, comentários e descrições foram inventados, porque o print não os mostrava.
- **Resolver os erros de versão sem quebrar o projeto.** No início o código foi adaptado às bibliotecas antigas (`Icons.Default.ArrowBack`, `smallTopAppBarColors`, `material-icons-extended`), em vez de atualizar tudo de uma vez. Depois o grupo atualizou o Gradle (ver decisões do Caio), e o código final já usa as APIs atuais.
- **Deixar a barra superior a cargo da `TopNavBar` central.** O `Video_Aberto` não tem `TopAppBar` própria; o botão de voltar vem da barra compartilhada, que usa `popBackStack()`.
- **Padronizar os nomes entre arquivos** (a função ficou `Video_Aberto`, igual à chamada no `NavHost`).

#### Decisões registradas pelo Heverton

- **Começar o projeto por `AppNavigation.kt` e `Rotas.kt`.** Essa abordagem se mostrou ineficiente ao longo do desenvolvimento, mas ajudou a delimitar quais arquivos precisavam existir.
- **Colocar Configurações na `TopNavigation`.** Originalmente a tela só seria acessível pela tela "Você". Como o acesso ficaria muito mais limitado que o das outras telas, o grupo decidiu facilitar o encontro dela colocando um ícone de engrenagem na barra superior.

#### Decisões registradas pelo Caio

- **Enviar o identificador do vídeo, canal ou playlist pela rota**, para cada tela mostrar o item certo.
- **Compartilhar o estado de inscrição entre as telas**, para que inscrever-se em um canal atualize a tela de Inscrições.
- **Tratar listas vazias com mensagens**, em vez de deixar a tela em branco.
- **Ajustar as versões do Gradle** para ficarem compatíveis entre si (AGP, Kotlin, Compose BOM e Navigation).

### Mudança do Trabalho 1 para o Trabalho 2

No T1, a `HomeScreen` era um wireframe feito só com `Box` cinza, sem dados nem cliques. No T2 ela virou o `Inicio`, uma lista dinâmica de vídeos que abre a tela de detalhes. A barra inferior de círculos fixos virou uma `NavigationBar` funcional, e o app passou de 1 tela para 7.

### Complexidade extra na tela de Detalhes

- **Ver Canal** combina dados das duas listas: mostra o `Canal` e a lista de vídeos dele, filtrada por `canalId` na `listaVideos`.
- **Vídeo Aberto** lê o estado de inscrição do `Canal` correspondente. Inscrever-se ali altera a `listaCanais`, e a mudança aparece em Inscrições e em Ver Canal.

_[CONFIRMAR: por que o grupo escolheu essa complexidade extra? Escreva aqui, com as palavras do grupo.]_

## Roteiro de demonstração

1. Abre em **Início**. Toque no vídeo 1 → abre "UM DIA COMIGO". Voltar → Início.
2. Aba **Inscrições**: aparece a mensagem de lista vazia. Em "Canais disponíveis", toque no Canal 1 → mostra o canal e os vídeos dele. Toque em "Inscrever-se".
3. Voltar → Inscrições agora lista o Canal 1 como inscrito, e o Canal 2 continua em "disponíveis".
4. Toque no Canal 2 → mostra só o vídeo 2. Toque no vídeo → abre o vídeo 2. Em "Inscrever-se" e depois voltando em Inscrições, o Canal 2 passou a inscrito.
5. Aba **Você**: perfil, atalhos para Inscrições e Configurações, histórico e playlists. "Assistir mais tarde" → vídeos 1 e 3; "Gameplays" → vídeo 2; "Playlist vazia" → mensagem de lista vazia.
6. Ícone de engrenagem na barra superior → **Configurações**.

## Dificuldades

**Heverton:** as principais dificuldades foram o `AppNavigation.kt` e a troca de telas em geral. Como faltavam arquivos, o código não levava a lugar nenhum, e houve vários erros que atrapalharam as primeiras fases de teste. Outra dificuldade foi aplicar o `BottomNavigation.kt` e o `TopNavigation.kt` nas outras telas: com os problemas iniciais, poucos testes puderam ser feitos. O grupo decidiu comentar trechos do `AppNavigation.kt` para facilitar o desenvolvimento dos demais arquivos, e assim o Bottom e o Top Navigation foram implementados com sucesso.

**Admar:** erros de versão em `Icons.AutoMirrored`, `topAppBarColors` e `ThumbDown`, porque o projeto usava bibliotecas antigas. A solução inicial foi adaptar o código e adicionar o `material-icons-extended`; depois as versões foram atualizadas no Gradle. Também houve erros por nomes diferentes entre arquivos (`Video_Aberto` e `VideoAberto`, `Incricoes` e `Inscricoes`), resolvidos padronizando os nomes.

**Caio:** a principal dificuldade foi integrar as telas ao restante do app e passar dados entre elas. Para resolver, enviou o identificador do item pela rota, compartilhou o estado de inscrição entre as telas e ajustou as versões do Gradle para ficarem compatíveis.

## Prints do app

Capturas feitas no emulador durante o desenvolvimento.

### Início

Feed de vídeos em `LazyColumn`, com a barra superior (logo, notificações, pesquisa e configurações) e a barra inferior com a aba "Início" ativa.

<img src="docs/prints/01_inicio.jpg" alt="Tela Início" width="300">

### Vídeo Aberto

Detalhes do vídeo escolhido na lista (aqui, "UM DIA COMIGO"), com botão de voltar, inscrição, curtir, descurtir, compartilhar e card de comentários.

<img src="docs/prints/02_video_aberto.jpg" alt="Tela Vídeo Aberto" width="300">

### Ver Canal

Página do canal com descrição, botão "Inscrever-se" e a lista de vídeos dele (2 vídeos), filtrada por `canalId`.

<img src="docs/prints/03_ver_canal.jpg" alt="Tela Ver Canal" width="300">

### Configurações

Opções agrupadas em Conta, Geral e Sobre, com atalhos para Inscrições e Playlist e `Checkbox` para notificações, reprodução automática e economia de dados.

<img src="docs/prints/04_configuracoes.jpg" alt="Tela Configurações" width="300">

---

_Trabalho acadêmico. Dados fictícios, com títulos e canais inspirados no YouTube._
